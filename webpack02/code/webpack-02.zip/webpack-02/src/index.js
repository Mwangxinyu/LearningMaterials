import css from "./style/index.less";

console.log("hello 老韩");

// 假如同学们拿到我这个项目 需要安装依赖
// 国内淘宝源
// 样式处理
//  css-loader style-loader
// postcss
